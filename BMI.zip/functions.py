def is_normal(boys_df,girls_df,age_in_days,height_in_cm,gender):
#     b_columns=np.array(boys_df.columns[4:-2])   
#     b_p15=np.array(boys_df[['P15']])
#     b_p85=np.array(boys_df[['P85']])
#     print(b_p85[1500])
    import pandas as pd
    import numpy as np
    if gender=='male':
        b_p15=np.array(boys_df[['P15']])
        b_p85=np.array(boys_df[['P85']])
        if (height_in_cm<b_p85[age_in_days]) and (height_in_cm>=b_p15[age_in_days]):
            return True
        else:
            return False
    elif gender=='female':
        g_p15=np.array(girls_df[['P15']])
        g_p85=np.array(girls_df[['P85']])
        if (height_in_cm<g_p85[age_in_days]) and (height_in_cm>=g_p15[age_in_days]):
            return True
        else:
            return False
