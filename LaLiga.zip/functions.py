import pandas as pd


def min_points(df_laliga, season):
    df=df_laliga[df_laliga['season'] == season].sort_values("points",ascending=False).tail(1)
    
    
    
    df=df.reset_index(drop=True,inplace=False)
    df=df[['club','points']].reset_index(drop=True, inplace=False)

    clb=df.set_index('club')['points'].to_dict()
    res =df.to_dict('r')
    return res[0]

def max_points(df_laliga, season):
    df=df_laliga[df_laliga['season'] == season].sort_values("points",ascending=False).head(1)
    
    print(df)
    
    df=df.reset_index(drop=True,inplace=False)
    df=df[['club','points']].reset_index(drop=True, inplace=False)

    clb=df.set_index('club')['points'].to_dict()
    res =df.to_dict('r')
    return res[0]