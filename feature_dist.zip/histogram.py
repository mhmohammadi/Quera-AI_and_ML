import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

matplotlib.use('Agg')


def show_hist(column, path=None):
    """
    Shows the histogram and number of elements in each bin
    :param column: name of column
    :param path: path of save figure
    :return: ndarray of number of elements in each bin
    """
    df_train = pd.read_csv('data/train.csv')
    IQR=df_train.column.quantile([0.25,0.75])
    bin_width=(IQR[1]-IQR[0])*2/df_train.column.count**(1/3)
    bin_count=df_train.column.count/bin_width
    # TODO
    
    
    
    
    import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.use('Agg')


def show_hist(column, path=None):
    df_train = pd.read_csv('data/train.csv')

    dft = df_train[column]

    quarts = dft.quantile([0.25, 0.5, 0.75])

    bin_count = int(np.ceil((dft.max() - dft.min()) / (2 * (quarts[0.75] - quarts[0.25]) / (dft.count() ** (1 / 3)))))

    hist = plt.hist(dft, bins=bin_count, color="blue")

    if path:
        plt.savefig(path)

    return hist[0]

    
    
    
    
    
    hist = plt.hist(df_train[column], bins=bin_count, color="blue")

    if path:
        plt.savefig(path)

    return hist[0]
