import numpy as np
import pandas as pd





def survival_chance(titanic_df,start_age,end_age):
    
    ages = titanic_df.Age[ ~titanic_df.Age.isna() ].values
    survived = titanic_df['Survived'][ ~titanic_df.Age.isna() ].values
    sex = titanic_df['Sex'][ ~titanic_df.Age.isna() ].values
    
    given_age_indices=np.logical_and(ages>=start_age , ages<=end_age)
    died= survived==0
    survivedd = survived ==1
    
    m_indices = (sex == 'male')
    f_indices = (sex == 'female')

    ## Survived Men
    m_age= np.logical_and(given_age_indices,m_indices)
    freqs_survived_m=np.logical_and(m_age,survivedd).sum()
    
    ## Survived Women
    f_age= np.logical_and(given_age_indices,f_indices)
    freqs_survived_f=np.logical_and(f_age,survivedd).sum()    
    
    ## Died
    freqs_died_m=np.logical_and(m_age,died).sum()
    freqs_died_f=np.logical_and(f_age,died).sum()
    
    ## chance calculation
    if freqs_survived_m==0:
        m_chance=-1
    else:
        m_chance=freqs_survived_m/(freqs_survived_m+freqs_died_m)
        m_chance= "{:.3f}".format(m_chance)
        m_chance=float(m_chance)
      
    if freqs_survived_f==0:
        f_chance=-1
    else:
        f_chance=freqs_survived_f/(freqs_survived_f+freqs_died_f)
        f_chance= "{:.3f}".format(f_chance)
        f_chance=float(f_chance)
        
        
    res={'female': f_chance,'male': m_chance}
 
    return res