import numpy as np
from numpy import unravel_index

def max_corr(dataframe):
    import numpy as np
    df=dataframe
    cor=df.corr()
    corr=np.array(cor)
    minn=0
    maxx=0
    corr[corr==1]=0
    corr[corr==-1]=0
    maxx=corr.max()
    minn=corr.min()
    a=np.where(cor==maxx)
    b=np.where(cor==minn)
    
    

    
    if maxx>abs(minn):
        r=a[0][0]
        c=a[0][1]
        cc=cor.columns.values[c]
        rr=cor.index.values[r]
        mx={rr,cc}
        return mx
        
    else:
        r=b[0][0]
        c=b[0][1]
        cc=cor.columns.values[c]
        rr=cor.index.values[r]
        mx={rr,cc}
        return mx
    